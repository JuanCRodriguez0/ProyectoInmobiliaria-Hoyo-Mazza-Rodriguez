using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Http;

namespace ProyectoInmobiliaria_Hoyo_Mazza_Rodriguez.Models
{
    public class Inmueble
    {
        [Key]
        public int IdInmueble { get; set; }

        [Required(ErrorMessage = "Debe seleccionar un propietario")]
        [Display(Name = "Propietario")]
        public int IdPropietario { get; set; }

        [Required(ErrorMessage = "Debe seleccionar un tipo de inmueble")]
        [Display(Name = "Tipo de inmueble")]
        public int IdTipoInmueble { get; set; }

        [Required(ErrorMessage = "La dirección es obligatoria")]
        public string Direccion { get; set; } = "";

        [Required]
        [Range(1, 50, ErrorMessage = "Ingrese una cantidad de ambientes válida")]
        public int Ambientes { get; set; }

        [Required]
        [Range(1, 100000, ErrorMessage = "Ingrese una superficie válida")]
        [Display(Name = "Superficie (m²)")]
        public decimal Superficie { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Ingrese un precio por día válido")]
        [Display(Name = "Precio por día")]
        public decimal PrecioPorDia { get; set; }

        [Display(Name = "Disponible")]
        public bool Disponible { get; set; } = true;

        // Ruta de la imagen de portada
        public string? Portada { get; set; }

        [NotMapped]
        public IFormFile? ArchivoPortada { get; set; }

        [NotMapped]
        public List<IFormFile>? ArchivosGaleria { get; set; }

        [NotMapped]
        public List<ImagenInmueble> Imagenes { get; set; } = new List<ImagenInmueble>();

        [NotMapped]
        [Display(Name = "Propietario")]
        public string? NombrePropietario { get; set; }

        [NotMapped]
        [Display(Name = "Tipo de inmueble")]
        public string? DescripcionTipoInmueble { get; set; }
    }
}