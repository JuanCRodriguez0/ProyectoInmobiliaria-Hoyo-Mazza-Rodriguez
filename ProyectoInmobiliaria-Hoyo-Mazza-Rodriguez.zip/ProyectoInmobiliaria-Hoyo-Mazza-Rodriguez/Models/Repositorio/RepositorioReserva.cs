using MySql.Data.MySqlClient;
using ProyectoInmobiliaria_Hoyo_Mazza_Rodriguez.Models;

namespace ProyectoInmobiliaria_Hoyo_Mazza_Rodriguez.Models
{
    public class RepositorioReserva
    {
        private readonly string connectionString;

        public RepositorioReserva(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection")!;
        }

        // 1 OBTENER TODAS LAS RESERVAS (con datos de inquilino e inmueble)
        public List<Reserva> ObtenerTodos()
        {
            var reservas = new List<Reserva>();

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"SELECT r.IdReserva, r.IdInquilino, r.IdInmueble, r.MontoPorDia, r.FechaDesde, r.FechaHasta,
                                   CONCAT(q.Apellido, ' ', q.Nombre) AS NombreInquilino,
                                   i.Direccion AS DireccionInmueble
                            FROM reservas r
                            INNER JOIN inquilinos q ON q.IdInquilino = r.IdInquilino
                            INNER JOIN inmuebles i ON i.IdInmueble = r.IdInmueble
                            ORDER BY r.FechaDesde DESC";

                using (var command = new MySqlCommand(sql, connection))
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            reservas.Add(LeerReserva(reader));
                        }
                    }
                }
            }
            return reservas;
        }

        // 2 OBTENER UNA RESERVA POR ID
        public Reserva? ObtenerPorId(int id)
        {
            Reserva? reserva = null;

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"SELECT r.IdReserva, r.IdInquilino, r.IdInmueble, r.MontoPorDia, r.FechaDesde, r.FechaHasta,
                                   CONCAT(q.Apellido, ' ', q.Nombre) AS NombreInquilino,
                                   i.Direccion AS DireccionInmueble
                            FROM reservas r
                            INNER JOIN inquilinos q ON q.IdInquilino = r.IdInquilino
                            INNER JOIN inmuebles i ON i.IdInmueble = r.IdInmueble
                            WHERE r.IdReserva = @id";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", id);
                    connection.Open();

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            reserva = LeerReserva(reader);
                        }
                    }
                }
            }
            return reserva;
        }

        private Reserva LeerReserva(MySqlDataReader reader)
        {
            return new Reserva
            {
                IdReserva = reader.GetInt32("IdReserva"),
                IdInquilino = reader.GetInt32("IdInquilino"),
                IdInmueble = reader.GetInt32("IdInmueble"),
                MontoPorDia = reader.GetDecimal("MontoPorDia"),
                FechaDesde = reader.GetDateTime("FechaDesde"),
                FechaHasta = reader.GetDateTime("FechaHasta"),
                NombreInquilino = reader.GetString("NombreInquilino"),
                DireccionInmueble = reader.GetString("DireccionInmueble")
            };
        }

        // 3 GUARDAR 
        public int Alta(Reserva reserva)
        {
            int res = -1;

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"INSERT INTO reservas (IdInquilino, IdInmueble, MontoPorDia, FechaDesde, FechaHasta)
                            VALUES (@idInquilino, @idInmueble, @montoPorDia, @fechaDesde, @fechaHasta);
                            SELECT LAST_INSERT_ID();";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@idInquilino", reserva.IdInquilino);
                    command.Parameters.AddWithValue("@idInmueble", reserva.IdInmueble);
                    command.Parameters.AddWithValue("@montoPorDia", reserva.MontoPorDia);
                    command.Parameters.AddWithValue("@fechaDesde", reserva.FechaDesde);
                    command.Parameters.AddWithValue("@fechaHasta", reserva.FechaHasta);

                    connection.Open();
                    res = Convert.ToInt32(command.ExecuteScalar());
                    reserva.IdReserva = res;
                }
            }
            return res;
        }

        // 4 MODIFICACIÓN DE RESERVA
        public int Modificacion(Reserva reserva)
        {
            int res = -1;

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"UPDATE reservas
                            SET IdInquilino = @idInquilino,
                                IdInmueble = @idInmueble,
                                MontoPorDia = @montoPorDia,
                                FechaDesde = @fechaDesde,
                                FechaHasta = @fechaHasta
                            WHERE IdReserva = @id";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", reserva.IdReserva);
                    command.Parameters.AddWithValue("@idInquilino", reserva.IdInquilino);
                    command.Parameters.AddWithValue("@idInmueble", reserva.IdInmueble);
                    command.Parameters.AddWithValue("@montoPorDia", reserva.MontoPorDia);
                    command.Parameters.AddWithValue("@fechaDesde", reserva.FechaDesde);
                    command.Parameters.AddWithValue("@fechaHasta", reserva.FechaHasta);

                    connection.Open();
                    res = command.ExecuteNonQuery();
                }
            }
            return res;
        }

        // 5 BAJA 
        public int Baja(int id)
        {
            int res = -1;

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"DELETE FROM reservas WHERE IdReserva = @id";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    connection.Open();
                    res = command.ExecuteNonQuery();
                }
            }
            return res;
        }

        // 6 VERIFICAR SUPERPOSICIÓN DE FECHAS PARA UN INMUEBLE
        
        public bool ExisteSuperposicion(int idInmueble, DateTime desde, DateTime hasta, int idReservaExcluir = 0)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"SELECT COUNT(*) FROM reservas
                            WHERE IdInmueble = @idInmueble
                              AND IdReserva <> @idReservaExcluir
                              AND FechaDesde <= @hasta
                              AND FechaHasta >= @desde";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@idInmueble", idInmueble);
                    command.Parameters.AddWithValue("@idReservaExcluir", idReservaExcluir);
                    command.Parameters.AddWithValue("@desde", desde);
                    command.Parameters.AddWithValue("@hasta", hasta);

                    connection.Open();
                    var cantidad = Convert.ToInt32(command.ExecuteScalar());
                    return cantidad > 0;
                }
            }
        }
    }
}