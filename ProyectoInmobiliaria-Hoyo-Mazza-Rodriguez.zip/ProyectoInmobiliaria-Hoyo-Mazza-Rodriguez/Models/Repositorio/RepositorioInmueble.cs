using MySql.Data.MySqlClient;
using ProyectoInmobiliaria_Hoyo_Mazza_Rodriguez.Models;

namespace ProyectoInmobiliaria_Hoyo_Mazza_Rodriguez.Models
{
    public class RepositorioInmueble
    {
        private readonly string connectionString;

        public RepositorioInmueble(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection")!;
        }

        // 1 OBTENER TODOS LOS INMUEBLES 
        public List<Inmueble> ObtenerTodos()
        {
            var inmuebles = new List<Inmueble>();

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"SELECT i.IdInmueble, i.IdPropietario, i.IdTipoInmueble, i.Direccion, i.Ambientes,
                                   i.Superficie, i.PrecioPorDia, i.Disponible, i.Portada,
                                   CONCAT(p.Apellido, ' ', p.Nombre) AS NombrePropietario,
                                   t.Descripcion AS DescripcionTipo
                            FROM inmuebles i
                            INNER JOIN propietarios p ON p.IdPropietario = i.IdPropietario
                            INNER JOIN tipos_inmueble t ON t.IdTipoInmueble = i.IdTipoInmueble
                            ORDER BY i.IdInmueble";

                using (var command = new MySqlCommand(sql, connection))
                {
                    connection.Open();
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            inmuebles.Add(LeerInmueble(reader));
                        }
                    }
                }
            }
            return inmuebles;
        }

        // 2 OBTENER UN INMUEBLE POR ID 
        public Inmueble? ObtenerPorId(int id)
        {
            Inmueble? inmueble = null;

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"SELECT i.IdInmueble, i.IdPropietario, i.IdTipoInmueble, i.Direccion, i.Ambientes,
                                   i.Superficie, i.PrecioPorDia, i.Disponible, i.Portada,
                                   CONCAT(p.Apellido, ' ', p.Nombre) AS NombrePropietario,
                                   t.Descripcion AS DescripcionTipo
                            FROM inmuebles i
                            INNER JOIN propietarios p ON p.IdPropietario = i.IdPropietario
                            INNER JOIN tipos_inmueble t ON t.IdTipoInmueble = i.IdTipoInmueble
                            WHERE i.IdInmueble = @id";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", id);
                    connection.Open();

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            inmueble = LeerInmueble(reader);
                        }
                    }
                }
            }

            if (inmueble != null)
            {
                inmueble.Imagenes = ObtenerImagenes(id);
            }

            return inmueble;
        }

        private Inmueble LeerInmueble(MySqlDataReader reader)
        {
            return new Inmueble
            {
                IdInmueble = reader.GetInt32("IdInmueble"),
                IdPropietario = reader.GetInt32("IdPropietario"),
                IdTipoInmueble = reader.GetInt32("IdTipoInmueble"),
                Direccion = reader.GetString("Direccion"),
                Ambientes = reader.GetInt32("Ambientes"),
                Superficie = reader.GetDecimal("Superficie"),
                PrecioPorDia = reader.GetDecimal("PrecioPorDia"),
                Disponible = reader.GetBoolean("Disponible"),
                Portada = reader.IsDBNull(reader.GetOrdinal("Portada")) ? null : reader.GetString("Portada"),
                NombrePropietario = reader.GetString("NombrePropietario"),
                DescripcionTipoInmueble = reader.GetString("DescripcionTipo")
            };
        }

        // 3 GUARDAR 
        public int Alta(Inmueble inmueble)
        {
            int res = -1;

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"INSERT INTO inmuebles (IdPropietario, IdTipoInmueble, Direccion, Ambientes, Superficie, PrecioPorDia, Disponible, Portada)
                            VALUES (@idPropietario, @idTipoInmueble, @direccion, @ambientes, @superficie, @precioPorDia, @disponible, @portada);
                            SELECT LAST_INSERT_ID();";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@idPropietario", inmueble.IdPropietario);
                    command.Parameters.AddWithValue("@idTipoInmueble", inmueble.IdTipoInmueble);
                    command.Parameters.AddWithValue("@direccion", inmueble.Direccion);
                    command.Parameters.AddWithValue("@ambientes", inmueble.Ambientes);
                    command.Parameters.AddWithValue("@superficie", inmueble.Superficie);
                    command.Parameters.AddWithValue("@precioPorDia", inmueble.PrecioPorDia);
                    command.Parameters.AddWithValue("@disponible", inmueble.Disponible);
                    command.Parameters.AddWithValue("@portada", (object?)inmueble.Portada ?? DBNull.Value);

                    connection.Open();
                    res = Convert.ToInt32(command.ExecuteScalar());
                    inmueble.IdInmueble = res;
                }
            }
            return res;
        }

        // 4. MODIFICACIÓN DE INMUEBLE
        public int Modificacion(Inmueble inmueble)
        {
            int res = -1;

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"UPDATE inmuebles
                            SET IdPropietario = @idPropietario,
                                IdTipoInmueble = @idTipoInmueble,
                                Direccion = @direccion,
                                Ambientes = @ambientes,
                                Superficie = @superficie,
                                PrecioPorDia = @precioPorDia,
                                Disponible = @disponible,
                                Portada = @portada
                            WHERE IdInmueble = @id";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", inmueble.IdInmueble);
                    command.Parameters.AddWithValue("@idPropietario", inmueble.IdPropietario);
                    command.Parameters.AddWithValue("@idTipoInmueble", inmueble.IdTipoInmueble);
                    command.Parameters.AddWithValue("@direccion", inmueble.Direccion);
                    command.Parameters.AddWithValue("@ambientes", inmueble.Ambientes);
                    command.Parameters.AddWithValue("@superficie", inmueble.Superficie);
                    command.Parameters.AddWithValue("@precioPorDia", inmueble.PrecioPorDia);
                    command.Parameters.AddWithValue("@disponible", inmueble.Disponible);
                    command.Parameters.AddWithValue("@portada", (object?)inmueble.Portada ?? DBNull.Value);

                    connection.Open();
                    res = command.ExecuteNonQuery();
                }
            }
            return res;
        }

        // 5 BAJA 
        public int Baja(int id)
        {
            int res = -1;

            using (var connection = new MySqlConnection(connectionString))
            {
                // Las imágenes se eliminan en cascada (ON DELETE CASCADE)
                var sql = @"DELETE FROM inmuebles WHERE IdInmueble = @id";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    connection.Open();
                    res = command.ExecuteNonQuery();
                }
            }
            return res;
        }

        // 6. VERIFICAR SI TIENE RESERVAS ASOCIADAS
        public bool TieneReservas(int id)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"SELECT COUNT(*) FROM reservas WHERE IdInmueble = @id";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", id);
                    connection.Open();
                    var cantidad = Convert.ToInt32(command.ExecuteScalar());
                    return cantidad > 0;
                }
            }
        }


        // OBTENER LAS IMÁGENES DE UN INMUEBLE
        public List<ImagenInmueble> ObtenerImagenes(int idInmueble)
        {
            var imagenes = new List<ImagenInmueble>();

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"SELECT IdImagen, IdInmueble, Ruta FROM inmueble_imagenes WHERE IdInmueble = @idInmueble";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@idInmueble", idInmueble);
                    connection.Open();

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            imagenes.Add(new ImagenInmueble
                            {
                                IdImagen = reader.GetInt32("IdImagen"),
                                IdInmueble = reader.GetInt32("IdInmueble"),
                                Ruta = reader.GetString("Ruta")
                            });
                        }
                    }
                }
            }
            return imagenes;
        }

        // AGREGAR UNA IMAGEN A LA GALERÍA
        public int AgregarImagen(int idInmueble, string ruta)
        {
            int res = -1;

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"INSERT INTO inmueble_imagenes (IdInmueble, Ruta) VALUES (@idInmueble, @ruta);
                            SELECT LAST_INSERT_ID();";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@idInmueble", idInmueble);
                    command.Parameters.AddWithValue("@ruta", ruta);

                    connection.Open();
                    res = Convert.ToInt32(command.ExecuteScalar());
                }
            }
            return res;
        }

        // OBTENER UNA IMAGEN POR ID 
        public ImagenInmueble? ObtenerImagenPorId(int idImagen)
        {
            ImagenInmueble? imagen = null;

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"SELECT IdImagen, IdInmueble, Ruta FROM inmueble_imagenes WHERE IdImagen = @idImagen";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@idImagen", idImagen);
                    connection.Open();

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            imagen = new ImagenInmueble
                            {
                                IdImagen = reader.GetInt32("IdImagen"),
                                IdInmueble = reader.GetInt32("IdInmueble"),
                                Ruta = reader.GetString("Ruta")
                            };
                        }
                    }
                }
            }
            return imagen;
        }

        // ELIMINAR UNA IMAGEN DE LA GALERÍA
        public int EliminarImagen(int idImagen)
        {
            int res = -1;

            using (var connection = new MySqlConnection(connectionString))
            {
                var sql = @"DELETE FROM inmueble_imagenes WHERE IdImagen = @idImagen";

                using (var command = new MySqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@idImagen", idImagen);

                    connection.Open();
                    res = command.ExecuteNonQuery();
                }
            }
            return res;
        }
    }
}