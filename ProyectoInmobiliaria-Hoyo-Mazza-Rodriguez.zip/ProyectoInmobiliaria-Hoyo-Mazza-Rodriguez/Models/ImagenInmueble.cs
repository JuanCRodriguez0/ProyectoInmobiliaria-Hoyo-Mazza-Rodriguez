using System.ComponentModel.DataAnnotations;

namespace ProyectoInmobiliaria_Hoyo_Mazza_Rodriguez.Models
{
    public class ImagenInmueble
    {
        [Key]
        public int IdImagen { get; set; }

        public int IdInmueble { get; set; }

        [Required]
        public string Ruta { get; set; } = "";
    }
}