using Microsoft.AspNetCore.Mvc;
using ProyectoInmobiliaria_Hoyo_Mazza_Rodriguez.Models;

namespace ProyectoInmobiliaria_Hoyo_Mazza_Rodriguez.Controllers
{
    public class InmuebleController : Controller
    {
        private readonly RepositorioInmueble repositorioInmueble;
        private readonly RepositorioPropietario repositorioPropietario;
        private readonly RepositorioTipoInmueble repositorioTipoInmueble;
        private readonly IWebHostEnvironment entorno;

        private const string CarpetaImagenes = "img/inmuebles";

        public InmuebleController(IConfiguration configuration, IWebHostEnvironment entorno)
        {
            repositorioInmueble = new RepositorioInmueble(configuration);
            repositorioPropietario = new RepositorioPropietario(configuration);
            repositorioTipoInmueble = new RepositorioTipoInmueble(configuration);
            this.entorno = entorno;
        }

        // GET: Inmueble
        public IActionResult Index()
        {
            var lista = repositorioInmueble.ObtenerTodos();
            return View(lista);
        }

        // GET: Inmueble/Details/5
        public IActionResult Details(int id)
        {
            var inmueble = repositorioInmueble.ObtenerPorId(id);
            if (inmueble == null)
            {
                return NotFound();
            }
            return View(inmueble);
        }

        // GET: Inmueble/Create
        public IActionResult Create()
        {
            CargarCombos();
            return View();
        }

        // POST: Inmueble/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Inmueble inmueble)
        {
            if (ModelState.IsValid)
            {
                // Guarda primero el inmueble para tener su Id
                if (inmueble.ArchivoPortada != null && inmueble.ArchivoPortada.Length > 0)
                {
                    inmueble.Portada = GuardarArchivo(inmueble.ArchivoPortada);
                }

                repositorioInmueble.Alta(inmueble);

                if (inmueble.ArchivosGaleria != null)
                {
                    foreach (var archivo in inmueble.ArchivosGaleria)
                    {
                        if (archivo.Length > 0)
                        {
                            var ruta = GuardarArchivo(archivo);
                            repositorioInmueble.AgregarImagen(inmueble.IdInmueble, ruta);
                        }
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            CargarCombos(inmueble.IdPropietario, inmueble.IdTipoInmueble);
            return View(inmueble);
        }

        // GET: Inmueble/Edit/5
        public IActionResult Edit(int id)
        {
            var inmueble = repositorioInmueble.ObtenerPorId(id);
            if (inmueble == null)
            {
                return NotFound();
            }
            CargarCombos(inmueble.IdPropietario, inmueble.IdTipoInmueble);
            return View(inmueble);
        }

        // POST: Inmueble/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Inmueble inmueble)
        {
            if (id != inmueble.IdInmueble)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                // Si cargó una nueva portada, la guardamos; si no, conservamos la actual
                if (inmueble.ArchivoPortada != null && inmueble.ArchivoPortada.Length > 0)
                {
                    inmueble.Portada = GuardarArchivo(inmueble.ArchivoPortada);
                }
                else
                {
                    var actual = repositorioInmueble.ObtenerPorId(id);
                    inmueble.Portada = actual?.Portada;
                }

                repositorioInmueble.Modificacion(inmueble);

                if (inmueble.ArchivosGaleria != null)
                {
                    foreach (var archivo in inmueble.ArchivosGaleria)
                    {
                        if (archivo.Length > 0)
                        {
                            var ruta = GuardarArchivo(archivo);
                            repositorioInmueble.AgregarImagen(inmueble.IdInmueble, ruta);
                        }
                    }
                }

                return RedirectToAction(nameof(Index));
            }

            CargarCombos(inmueble.IdPropietario, inmueble.IdTipoInmueble);
            inmueble.Imagenes = repositorioInmueble.ObtenerImagenes(id);
            return View(inmueble);
        }

        // POST: Inmueble/EliminarImagen/5  
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EliminarImagen(int idImagen, int idInmueble)
        {
            var imagen = repositorioInmueble.ObtenerImagenPorId(idImagen);
            if (imagen != null)
            {
                EliminarArchivoFisico(imagen.Ruta);
                repositorioInmueble.EliminarImagen(idImagen);
            }
            return RedirectToAction(nameof(Edit), new { id = idInmueble });
        }

        // GET: Inmueble/Delete/5
        public IActionResult Delete(int id)
        {
            var inmueble = repositorioInmueble.ObtenerPorId(id);
            if (inmueble == null)
            {
                return NotFound();
            }

            ViewBag.TieneReservas = repositorioInmueble.TieneReservas(id);
            return View(inmueble);
        }

        // POST: Inmueble/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            if (repositorioInmueble.TieneReservas(id))
            {
                ModelState.AddModelError("", "No se puede eliminar: el inmueble tiene reservas asociadas.");
                var inmueble = repositorioInmueble.ObtenerPorId(id);
                ViewBag.TieneReservas = true;
                return View("Delete", inmueble);
            }

            var actual = repositorioInmueble.ObtenerPorId(id);
            if (actual != null)
            {
                EliminarArchivoFisico(actual.Portada);
                foreach (var img in actual.Imagenes)
                {
                    EliminarArchivoFisico(img.Ruta);
                }
            }

            repositorioInmueble.Baja(id);
            return RedirectToAction(nameof(Index));
        }


        private void CargarCombos(int? idPropietarioSeleccionado = null, int? idTipoSeleccionado = null)
        {
            // Usamos una proyección para mostrar "Apellido, Nombre" en el combo
            var propietarios = repositorioPropietario.ObtenerTodos()
                .Select(p => new { p.IdPropietario, NombreCompleto = $"{p.Apellido}, {p.Nombre}" });
            ViewBag.Propietarios = new Microsoft.AspNetCore.Mvc.Rendering.SelectList(
                propietarios, "IdPropietario", "NombreCompleto", idPropietarioSeleccionado);

            ViewBag.TiposInmueble = new Microsoft.AspNetCore.Mvc.Rendering.SelectList(
                repositorioTipoInmueble.ObtenerTodos(), "IdTipoInmueble", "Descripcion", idTipoSeleccionado);
        }

        private string GuardarArchivo(IFormFile archivo)
        {
            var carpetaDestino = Path.Combine(entorno.WebRootPath, CarpetaImagenes);
            Directory.CreateDirectory(carpetaDestino);

            var nombreArchivo = $"{Guid.NewGuid()}{Path.GetExtension(archivo.FileName)}";
            var rutaFisica = Path.Combine(carpetaDestino, nombreArchivo);

            using (var stream = new FileStream(rutaFisica, FileMode.Create))
            {
                archivo.CopyTo(stream);
            }

            // Ruta relativa que se guarda en la base de datos y se usa en las vistas
            return $"/{CarpetaImagenes}/{nombreArchivo}";
        }

        private void EliminarArchivoFisico(string? rutaRelativa)
        {
            if (string.IsNullOrEmpty(rutaRelativa))
            {
                return;
            }

            var rutaFisica = Path.Combine(entorno.WebRootPath, rutaRelativa.TrimStart('/').Replace('/', Path.DirectorySeparatorChar));
            if (System.IO.File.Exists(rutaFisica))
            {
                System.IO.File.Delete(rutaFisica);
            }
        }
    }
}